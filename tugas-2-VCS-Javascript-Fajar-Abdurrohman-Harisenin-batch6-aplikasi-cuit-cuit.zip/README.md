# cuit-cuit-tailwind-css
Web app seperti twitter sederhana yang bernama "cuit-cuit" yaitu suara burung yang biasa terdengar oleh orang-orang Jawa di Indonesia. Menggunakan framework Tailwind css serta manipulasi DOM. Terimakasih
